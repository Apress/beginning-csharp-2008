namespace CrepeRecipeFirstAttempt {
    public class Chef {
        public static void MakeCrepe() {
            /*
            Crepe crepe = new Crepe();

            crepe.BreakEggs(2);
            crepe.AddSugar(100);
            crepe.AddMilk(100);
            crepe.AddFlour(100);
            crepe.Mix();

            crepe.HeatPan();

            crepe.PourBatterIntoPan();
            crepe.WaitUntilFirm();
            crepe.Flip();
            crepe.WaitUntilBrown();

            crepe.RemoveFromPan();
             * */
        }
    }
}