using System;
using System.Collections.Generic;
using System.Text;

namespace Example2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hello world");
            Example3.Class1.HelloWorld();
        }
    }
}
