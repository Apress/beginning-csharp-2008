using System;
using System.Collections.Generic;
using System.Text;

namespace Example3
{
    public class Class1
    {
        const string message = "hello world";

        public static void HelloWorld()
        {
            Console.WriteLine("hello world");
        }
    }
}
