﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace OneToManySamples {
    class Program {
        static void Main(string[] args) {
            //BeforeCShap2dot0.Tests.RunAll();
            //AfterCSharp2dot0.Tests.RunAll();
            //InitialProblem.Tests.RunAll();
            //Delegates.Tests.RunAll();
            Spreadsheets.Tests.RunAll();
            Console.ReadKey();
        }
    }
}
