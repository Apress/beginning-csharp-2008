namespace Devspace.Trader.Common
{
public interface IDebug {
    bool Debug { get; set; }
}
    
}
