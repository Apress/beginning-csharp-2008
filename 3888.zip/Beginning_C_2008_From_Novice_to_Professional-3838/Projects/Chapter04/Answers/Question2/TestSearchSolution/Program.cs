using System;
using System.Collections.Generic;
using System.Text;

namespace TestSearchSolution {
    class Program {
        static void Main(string[] args) {
            TestSearchSolution.Run();
            //ValueTypeConstraints.Run();
            Console.ReadKey();
        }
    }
}
