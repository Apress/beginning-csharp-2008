﻿using System;
using System.Linq;
using System.Collections;
using System.Text;
using LibLightingSystem;

namespace Museum {
    class PrivateRoom : INoRemoteControlRoom {
    }
}
