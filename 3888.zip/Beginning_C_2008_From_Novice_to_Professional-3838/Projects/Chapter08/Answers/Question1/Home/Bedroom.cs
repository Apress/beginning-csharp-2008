﻿using System;
using System.Linq;
using System.Collections;
using System.Text;
using LibLightingSystem;

namespace Home {
    class Bedroom : INoRemoteControlRoom {
    }
}
