﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace LibTax {
    public interface ITaxDeduction {
        double Amount { get; }
    }
}
